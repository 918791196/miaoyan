# -*- coding: utf-8 -*-
# Time    : 2018/12/24 22:06
# Author  : 辛放
# Email   : 1374520110@qq.com
# ID      : SZ160110115
# File    : 1.py
# Software: PyCharm
from docx import Document
from docx.shared import Inches
from pyecharts_snapshot.main import make_a_snapshot
import pdfkit
make_a_snapshot('db201501.html','test.pdf')