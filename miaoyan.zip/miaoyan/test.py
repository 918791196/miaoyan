# -*- coding: utf-8 -*-
# Time    : 2018/12/16 13:28
# Author  : 辛放
# Email   : 1374520110@qq.com
# ID      : SZ160110115
# File    : test.py
# Software: PyCharm
from PyQt5 import QtCore, QtGui, QtWidgets
import Mine
from PyQt5 import QtCore
from PyQt5 import QtWidgets
from PyQt5.QtCore import *
import pandas as pd
import pymysql
import os
import pyecharts
from pyecharts import WordCloud
from collections import Counter
from PyQt5.QtGui import QMovie

year = 2015
top = 3
conn = pymysql.connect(host='localhost', user='root', password='201314xIn', port=3306, db='maoyan',
                       charset='utf8mb4')
sql = "select year,actor1,actor2,actor3,actor4 from films"
db_0 = pd.read_sql(sql, conn)
db = db_0[(db_0.year == year)]
dict = dict(Counter(db['actor1'].append(db['actor2']).append(db['actor3']).append(
    db['actor4']).dropna()).most_common(top))
print(dict)
x = list(dict.keys())
print()
y = list(dict.values())
top_Bar = pyecharts.Bar()
top_Bar.add("", x, y, mark_line=['max'], xaxis_interval=0, is_labal_show=True)
top_Bar.render("t4%d.html" % (year * 100 + top))
value10 = [965, 847, 582, 555, 550, 462, 366, 360, 282, 273]
value = value10[0:top]
print(value)
word = WordCloud()
word.add("", x, value, word_size_range=[20, 40])
word.render("wct%d.html" % (year * 100 + top))